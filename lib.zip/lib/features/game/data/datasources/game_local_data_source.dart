import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../../domain/entities/situation.dart';
import '../models/situation_model.dart';

abstract class GameLocalDataSource {
  Future<List<Situation>> getSituations();
  Future<CommunityStats> vote({required String situationId, required Choice choice});
}

class GameLocalDataSourceImpl implements GameLocalDataSource {
  // Наша полная база данных (загружается из JSON)
  List<Situation> _loadedSituations = [];
  
  // Кэш текущей сессии (случайные 10 карточек)
  List<Situation> _currentRoundSituations = [];

  @override
  Future<List<Situation>> getSituations() async {
    // Если база еще не считана — грузим её один раз из ресурсов
    if (_loadedSituations.isEmpty) {
      final String jsonString = await rootBundle.loadString('assets/situations.json');
      final List<dynamic> jsonList = json.decode(jsonString);
      _loadedSituations = jsonList.map((json) => SituationModel.fromJson(json)).toList();
    }

    // Делаем копию базы для перемешивания
    final List<Situation> shuffled = List.from(_loadedSituations);
    
    // ПЕРЕМЕШИВАЕМ КАРТОЧКИ
    shuffled.shuffle();

    // БЕРЕМ СЕССИЮ ИЗ 10 СЛУЧАЙНЫХ ВОПРОСОВ
    final int roundSize = shuffled.length < 10 ? shuffled.length : 10;
    _currentRoundSituations = shuffled.take(roundSize).toList();

    return _currentRoundSituations;
  }

  @override
  Future<CommunityStats> vote({
    required String situationId,
    required Choice choice,
  }) async {
    // Имитируем сетевую задержку
    await Future.delayed(const Duration(milliseconds: 200));

    final index = _currentRoundSituations.indexWhere((element) => element.id == situationId);
    if (index == -1) {
      throw Exception('Ситуация не найдена в текущем раунде');
    }

    final currentSituation = _currentRoundSituations[index];
    final currentStats = currentSituation.stats;

    final updatedStats = CommunityStats(
      baseVotes: choice == Choice.base ? currentStats.baseVotes + 1 : currentStats.baseVotes,
      cringeVotes: choice == Choice.cringe ? currentStats.cringeVotes + 1 : currentStats.cringeVotes,
    );

    _currentRoundSituations[index] = Situation(
      id: currentSituation.id,
      text: currentSituation.text,
      category: currentSituation.category,
      stats: updatedStats,
      comments: currentSituation.comments,
      baseTrait: currentSituation.baseTrait,
      cringeTrait: currentSituation.cringeTrait,
    );

    return updatedStats;
  }
}