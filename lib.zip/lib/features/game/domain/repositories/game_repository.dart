import '../entities/situation.dart';

abstract class GameRepository {
  /// Получить список ситуаций для игры
  Future<List<Situation>> getSituations();

  /// Отправить голос пользователя
  Future<CommunityStats> vote({
    required String situationId,
    required Choice choice,
  });
}