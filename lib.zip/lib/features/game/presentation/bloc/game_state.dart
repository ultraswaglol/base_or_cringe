import '../../domain/entities/situation.dart';

abstract class GameState {}

class GameLoading extends GameState {}

class GameError extends GameState {
  final String message;
  GameError(this.message);
}

/// Состояние ожидания выбора игрока
class GameActiveCard extends GameState {
  final Situation situation;
  final int currentIndex;
  final int totalCount;

  GameActiveCard({
    required this.situation,
    required this.currentIndex,
    required this.totalCount,
  });
}

/// Состояние после клика на "База" или "Кринж"
class GameVotedState extends GameState {
  final Situation situation;
  final Choice userChoice;
  final CommunityStats updatedStats;
  final int currentIndex;
  final int totalCount;

  GameVotedState({
    required this.situation,
    required this.userChoice,
    required this.updatedStats,
    required this.currentIndex,
    required this.totalCount,
  });
}

/// Все ситуации пройдены, пора считать результаты
class GameFinished extends GameState {
  final List<Map<Situation, Choice>> history; // История выборов для диагностики

  GameFinished(this.history);
}